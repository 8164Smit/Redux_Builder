import TaskBuilder from './components/TaskBuilder'

function App() {
  return <TaskBuilder />
}

export default App
