import { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { addTask, deleteTask } from '../features/tasks/taskSlice'

function TaskBuilder() {
    const [task, setTask] = useState('')
    const dispatch = useDispatch()
    const tasks = useSelector(state => state.tasks.list)

    const handleAdd = () => {
        if (task.trim()) {
            dispatch(addTask(task))
            setTask('')
        }
    }

    return (
        <div className="container">
            <h1>Redux Task Builder</h1>

            <div className="input-box">
                <input
                    type="text"
                    value={task}
                    placeholder="Enter new task"
                    onChange={e => setTask(e.target.value)}
                />
                <button onClick={handleAdd}>Add</button>
            </div>

            <ul className="task-list">
                {tasks.map(item => (
                    <li key={item.id}>
                        <span>{item.title}</span>
                        <button onClick={() => dispatch(deleteTask(item.id))}>
                            ✖
                        </button>
                    </li>
                ))}
            </ul>
        </div>
    )
}

export default TaskBuilder
